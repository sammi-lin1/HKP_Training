package com.example.intentschallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class NewContact extends AppCompatActivity implements View.OnClickListener {
    EditText tvName, tvNumber, tvWebsite, tvLocation;
    ImageView btnHappy, btnMeh, btnSad;


    @Override
    public void onClick(View v) {
        if(tvName.getText().toString().isEmpty() || tvNumber.getText().toString().isEmpty() ||
                tvWebsite.getText().toString().isEmpty() || tvLocation.getText().toString().isEmpty()) {
            Toast.makeText(NewContact.this, "Enter all fields!", Toast.LENGTH_SHORT).show();

        }
        else {
            String name = tvName.getText().toString().trim();
            int number = Integer.parseInt(tvNumber.getText().toString().trim());
            String website = tvWebsite.getText().toString().trim();
            String location = tvLocation.getText().toString().trim();

            Intent intent = new Intent();
            intent.putExtra("name", tvName.getText().toString().trim());
            intent.putExtra("number", tvNumber.getText().toString().trim());
            intent.putExtra("website", tvWebsite.getText().toString().trim());
            intent.putExtra("location", tvLocation.getText().toString().trim());

            if(v.getId() == R.id.btnHappy) {
                intent.putExtra("sentiment", "happy");
            }
            else if(v.getId() == R.id.btnMeh) {
                intent.putExtra("sentiment", "meh");
            }
            else {
                intent.putExtra("sentiment", "sad");
            }
            setResult(RESULT_OK, intent);
            NewContact.this.finish();

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_contact);

        tvName = findViewById(R.id.tvName);
        tvNumber = findViewById(R.id.tvNumber);
        tvWebsite = findViewById(R.id.tvWebsite);
        tvLocation = findViewById(R.id.tvLocation);

        btnHappy = findViewById(R.id.btnHappy);
        btnMeh = findViewById(R.id.btnMeh);
        btnSad = findViewById(R.id.btnSad);

        btnHappy.setOnClickListener(this);
        btnMeh.setOnClickListener(this);
        btnSad.setOnClickListener(this);
    }
}