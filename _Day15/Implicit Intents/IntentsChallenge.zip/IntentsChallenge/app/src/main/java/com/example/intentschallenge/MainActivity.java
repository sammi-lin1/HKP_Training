package com.example.intentschallenge;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnCreate;
    ImageView ivSentiment, ivCall, ivWebsite, ivLocation;
    final int CREATE_CONTACT = 1;
    String name = "", number = "", web = "", map = "", mood = "";


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CREATE_CONTACT) {
            if(resultCode == RESULT_OK) {
                ivSentiment.setVisibility(View.VISIBLE);
                ivCall.setVisibility(View.VISIBLE);
                ivWebsite.setVisibility(View.VISIBLE);
                ivLocation.setVisibility(View.VISIBLE);

                name = data.getStringExtra("name");
                number = data.getStringExtra("number");
                web = data.getStringExtra("website");
                map = data.getStringExtra("location");
                mood = data.getStringExtra("sentiment");

                if(mood.equals("happy")) {
                    ivSentiment.setImageResource(R.drawable.happy);
                }
                else if(mood.equals("meh")) {
                    ivSentiment.setImageResource(R.drawable.meh);
                }
                else {
                    ivSentiment.setImageResource((R.drawable.sad));
                }
            }
        }
        else {
            Toast.makeText(this, "No data passed through", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCreate = findViewById(R.id.btnCreate);
        ivSentiment = findViewById(R.id.ivSentiment2);
        ivCall = findViewById(R.id.ivCall2);
        ivWebsite = findViewById(R.id.ivWebsite2);
        ivLocation = findViewById(R.id.ivLocation2);
        btnCreate = findViewById(R.id.btnCreate);

        ivSentiment.setVisibility(View.GONE);
        ivCall.setVisibility(View.GONE);
        ivWebsite.setVisibility(View.GONE);
        ivLocation.setVisibility(View.GONE);

        String number = getIntent().getStringExtra("number");
        String website = getIntent().getStringExtra("website");
        String location = getIntent().getStringExtra("location");

        ivCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
                startActivity(intent);
            }
        });

        ivWebsite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://" + website));
                startActivity(intent);
            }
        });

        ivLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="+ location));
                startActivity(intent);

            }
        });

        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,
                        com.example.intentschallenge.NewContact.class);
                startActivityForResult(intent, CREATE_CONTACT);
            }
        });


    }
}