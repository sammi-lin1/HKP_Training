package com.raywenderlich.android.rwandroidtutorial

interface DependencyInjector {
    fun weatherRepository() : WeatherRepository
}
