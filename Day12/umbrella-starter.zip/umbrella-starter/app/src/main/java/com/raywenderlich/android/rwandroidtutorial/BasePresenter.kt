package com.raywenderlich.android.rwandroidtutorial

interface BasePresenter {
    fun onDestroy()
}