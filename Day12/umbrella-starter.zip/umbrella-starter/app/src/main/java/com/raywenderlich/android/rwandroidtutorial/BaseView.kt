package com.raywenderlich.android.rwandroidtutorial

interface BaseView<T> {
    fun setPresenter(presenter : T)
}
interface MainContract {
    interface Presenter : BasePresenter {
        fun onViewCreated()
        fun onLoadWeatherTapped()
    }

    interface View : BaseView<Presenter> {
        fun displayWeatherState(weatherState: WeatherState)
    }
}
