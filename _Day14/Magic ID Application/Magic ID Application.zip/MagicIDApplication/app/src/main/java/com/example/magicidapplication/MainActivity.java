package com.example.magicidapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etID;
    Button btnSubmit;
    TextView tvResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //the following code will connect our new variables to the activity_main.xml file
        etID = findViewById(R.id.etID);
        btnSubmit = findViewById(R.id.btnSubmit);
        tvResults = findViewById(R.id.tvResults);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //after we get text we must convert it to string to store it in a string var
                String idNumber = etID.getText().toString().trim(); //trim will remove spaces
                String dob = idNumber.substring(0, 6);
                //Changes char to string to int
                int gender = Integer.parseInt(Character.toString(idNumber.charAt(6)));
                String sGender;
                if(gender < 5) {
                    sGender = getString(R.string.female);
                } else
                    sGender = getString(R.string.male);
                int nationality = Integer.parseInt(Character.toString(idNumber.charAt(10)));
                String sNationality;
                if(nationality == 0)
                    sNationality = getString(R.string.sa_citizen);
                else
                    sNationality = getString(R.string.perm_resident);

                String text = getString(R.string.dob) + dob + getString(R.string.newLine) +
                        getString(R.string.gender) + sGender + getString(R.string.newLine) +
                        getString(R.string.nationality) + sNationality;

                tvResults.setText(text);
            }
        });
    }
}