package com.example.cricketchirps;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    EditText etNumber;
    Button btnCalculator;
    TextView tvResults;
    DecimalFormat formatter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumber = findViewById(R.id.etNumber);
        btnCalculator = findViewById(R.id.btnCalculate);
        tvResults = findViewById(R.id.tvResults);
        tvResults.setVisibility(View.GONE);
        formatter = new DecimalFormat("#0.0");

        btnCalculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etNumber.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
                else {
                    int chirps = Integer.parseInt(etNumber.getText().toString().trim());
                    double temp = (chirps/3.0) + 4;
                    String results = "The approximate tempature outside is " +  formatter.format(temp) + " degrees Celsius.";
                    tvResults.setText(results);
                    tvResults.setVisibility(View.VISIBLE);


                }
            }
        });
    }
}